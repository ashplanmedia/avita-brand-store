<?php
namespace Instamojo\Imojo\Logger;

class Logger extends \Monolog\Logger
{
}